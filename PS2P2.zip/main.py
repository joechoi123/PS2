
LastName=input("Enter a Last Name: ")
hours=float(input("Enter amount of hours: "))
HourlyPay=float(input("Enter hourly rate: "))

p=(hours * HourlyPay)

print(LastName)
print("Gross pay: ",p)