
Item=float(input("Enter item price: "))
Discount=float(input("Enter discount percent: "))

d=(Discount * .01)
p=(Item * d)
p2=(Item - p)

print("Discount: $", p)
print("Discount price: $", p2)