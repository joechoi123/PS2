
q1=float(input("Enter Unit"))
q2=float(input("Enter Price"))

TotalPrice=(q1 * q2)

print("Extended Price: ",TotalPrice)