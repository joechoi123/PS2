
L=float(input("Enter Length: "))
W=float(input("Enter W: "))

a=(L * W)
c=(L + W) * 2

print("Area of rectangle: ", a)
print("Circumference of rectangle: ", c)
