
LastName=input("Enter a last name: ")
Credits=float(input("Enter amount of credits: "))

p = (Credits * 250) + 100

print("Tuition is : ", p)
print(LastName)